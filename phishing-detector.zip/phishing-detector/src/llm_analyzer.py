"""
Optional AI (LLM) layer.

The ML models give a fast probability score. This module asks a large language
model for a second opinion and a plain-English explanation. It is optional:
if no API key is set, the system falls back to the rule-based explanation.

Set one of these environment variables to enable it:
    ANTHROPIC_API_KEY   (uses the Claude Messages API)
    OPENAI_API_KEY      (uses the OpenAI Chat Completions API)
Optional: LLM_MODEL to override the model name.

Uses only the Python standard library (urllib), so no extra install is needed.
"""
import json
import os
import re
import urllib.error
import urllib.request

PROMPT = """You are a cyber-security analyst. Decide whether the following {kind} is a phishing attempt.
A machine-learning model scored it {score:.0%} likely to be phishing.
Rule-based red flags found: {flags}

{kind_title} to analyse:
<<<
{content}
>>>

Reply ONLY with JSON in this exact shape:
{{"verdict": "phishing" | "suspicious" | "legitimate",
  "confidence": <number 0-1>,
  "reasons": ["short reason", "..."],
  "advice": "one sentence telling the user what to do"}}"""


def _post(url, headers, body, timeout=20):
    req = urllib.request.Request(url, data=json.dumps(body).encode(), headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())


def _call_anthropic(prompt):
    data = _post(
        "https://api.anthropic.com/v1/messages",
        {"x-api-key": os.environ["ANTHROPIC_API_KEY"],
         "anthropic-version": "2023-06-01", "content-type": "application/json"},
        {"model": os.getenv("LLM_MODEL", "claude-sonnet-5-5"), "max_tokens": 500,
         "messages": [{"role": "user", "content": prompt}]},
    )
    return data["content"][0]["text"]


def _call_openai(prompt):
    data = _post(
        "https://api.openai.com/v1/chat/completions",
        {"Authorization": f"Bearer {os.environ['OPENAI_API_KEY']}",
         "content-type": "application/json"},
        {"model": os.getenv("LLM_MODEL", "gpt-4o-mini"), "temperature": 0,
         "messages": [{"role": "user", "content": prompt}]},
    )
    return data["choices"][0]["message"]["content"]


def llm_available():
    return bool(os.getenv("ANTHROPIC_API_KEY") or os.getenv("OPENAI_API_KEY"))


def analyse(kind, content, ml_score, flags):
    """Returns a dict, or None if no LLM is configured / the call fails."""
    if not llm_available():
        return None
    prompt = PROMPT.format(kind=kind, kind_title=kind.title(), score=ml_score,
                           flags="; ".join(flags) or "none", content=content[:4000])
    try:
        text = _call_anthropic(prompt) if os.getenv("ANTHROPIC_API_KEY") else _call_openai(prompt)
        match = re.search(r"\{.*\}", text, re.S)
        result = json.loads(match.group(0)) if match else None
        if result:
            result["confidence"] = float(result.get("confidence", 0.5))
        return result
    except (urllib.error.URLError, KeyError, ValueError, TimeoutError) as e:
        return {"error": f"LLM unavailable: {e}"}
