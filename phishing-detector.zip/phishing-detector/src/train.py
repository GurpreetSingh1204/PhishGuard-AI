"""
Trains both models and saves them to models/.

    python src/train.py

URL model   : Random Forest on 24 hand-crafted lexical features
Email model : TF-IDF (word 1-2 grams) + Logistic Regression
Also writes models/metrics.json with accuracy / precision / recall / F1.
"""
import json
import os
import sys

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, classification_report,
                             confusion_matrix, f1_score, precision_score,
                             recall_score, roc_auc_score)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from features import URL_FEATURE_NAMES, clean_email_text, url_feature_vector  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")
MODELS = os.path.join(ROOT, "models")


def metrics(y_true, y_pred, y_prob):
    return {
        "accuracy": round(accuracy_score(y_true, y_pred), 4),
        "precision": round(precision_score(y_true, y_pred), 4),
        "recall": round(recall_score(y_true, y_pred), 4),
        "f1": round(f1_score(y_true, y_pred), 4),
        "roc_auc": round(roc_auc_score(y_true, y_prob), 4),
        "confusion_matrix": confusion_matrix(y_true, y_pred).tolist(),
    }


def train_url_model():
    df = pd.read_csv(os.path.join(DATA, "urls.csv")).dropna()
    X = np.array([url_feature_vector(u) for u in df["url"]])
    y = df["label"].astype(int).values
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

    model = RandomForestClassifier(n_estimators=200, max_depth=None,
                                   class_weight="balanced", n_jobs=-1, random_state=42)
    model.fit(Xtr, ytr)
    pred, prob = model.predict(Xte), model.predict_proba(Xte)[:, 1]

    print("\n=== URL model (Random Forest) ===")
    print(classification_report(yte, pred, target_names=["legitimate", "phishing"]))
    importances = sorted(zip(URL_FEATURE_NAMES, model.feature_importances_),
                         key=lambda t: t[1], reverse=True)
    print("Top features:", ", ".join(f"{n}={v:.3f}" for n, v in importances[:8]))

    joblib.dump(model, os.path.join(MODELS, "url_model.joblib"))
    m = metrics(yte, pred, prob)
    m["top_features"] = [[n, round(float(v), 4)] for n, v in importances[:10]]
    return m


def train_email_model():
    df = pd.read_csv(os.path.join(DATA, "emails.csv")).dropna()
    X = df["text"].map(clean_email_text)
    y = df["label"].astype(int).values
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

    pipe = Pipeline([
        ("tfidf", TfidfVectorizer(ngram_range=(1, 2), min_df=2, max_features=20000,
                                  sublinear_tf=True)),
        ("clf", LogisticRegression(max_iter=2000, class_weight="balanced")),
    ])
    pipe.fit(Xtr, ytr)
    pred, prob = pipe.predict(Xte), pipe.predict_proba(Xte)[:, 1]

    print("\n=== Email model (TF-IDF + Logistic Regression) ===")
    print(classification_report(yte, pred, target_names=["legitimate", "phishing"]))
    joblib.dump(pipe, os.path.join(MODELS, "email_model.joblib"))
    return metrics(yte, pred, prob)


if __name__ == "__main__":
    os.makedirs(MODELS, exist_ok=True)
    for f in ("urls.csv", "emails.csv"):
        if not os.path.exists(os.path.join(DATA, f)):
            sys.exit(f"Missing data/{f}. Run: python data/generate_dataset.py")
    results = {"url_model": train_url_model(), "email_model": train_email_model()}
    with open(os.path.join(MODELS, "metrics.json"), "w") as fh:
        json.dump(results, fh, indent=2)
    print("\nSaved models and metrics to", MODELS)
