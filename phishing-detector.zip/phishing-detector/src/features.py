"""
Feature extraction for phishing detection.

Two families of features:
  1. URL lexical features  -> used by the URL classifier (Random Forest)
  2. Email text features   -> used by the email classifier (TF-IDF + Logistic Regression)
     plus a few hand-crafted "red flag" signals used for explanations.
"""
import ipaddress
import math
import re
from collections import Counter
from urllib.parse import urlparse

SUSPICIOUS_WORDS = [
    "login", "verify", "update", "secure", "account", "bank", "confirm",
    "signin", "password", "webscr", "ebayisapi", "lucky", "bonus", "free",
    "wallet", "suspend", "unlock", "billing", "kyc", "reward",
]
SUSPICIOUS_TLDS = {
    "tk", "ml", "ga", "cf", "gq", "xyz", "top", "work", "click", "zip",
    "review", "country", "kim", "loan", "men", "icu", "buzz", "rest",
}
SHORTENERS = {
    "bit.ly", "goo.gl", "tinyurl.com", "ow.ly", "t.co", "is.gd", "buff.ly",
    "adf.ly", "cutt.ly", "rb.gy", "shorturl.at", "tiny.cc",
}
BRANDS = [
    "paypal", "apple", "microsoft", "amazon", "netflix", "google", "facebook",
    "instagram", "sbi", "hdfc", "icici", "paytm", "phonepe", "whatsapp",
]

URL_FEATURE_NAMES = [
    "url_length", "host_length", "path_length", "num_dots", "num_hyphens",
    "num_at", "num_question", "num_equal", "num_underscore", "num_slash",
    "num_digits", "digit_ratio", "num_subdomains", "has_ip", "has_https",
    "has_port", "is_shortener", "suspicious_tld", "suspicious_word_count",
    "brand_in_subdomain_or_path", "has_double_slash_redirect", "entropy",
    "has_punycode", "query_params",
]


def _normalise(url: str) -> str:
    url = url.strip()
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", url):
        url = "http://" + url
    return url


def _entropy(s: str) -> float:
    if not s:
        return 0.0
    counts = Counter(s)
    n = len(s)
    return -sum((c / n) * math.log2(c / n) for c in counts.values())


def _is_ip(host: str) -> bool:
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        return False


def extract_url_features(url: str) -> dict:
    raw = url.strip()
    parsed = urlparse(_normalise(raw))
    host = (parsed.hostname or "").lower()
    path = parsed.path or ""
    lower = raw.lower()

    parts = host.split(".") if host else []
    tld = parts[-1] if parts else ""
    registered = ".".join(parts[-2:]) if len(parts) >= 2 else host
    sub_and_path = (".".join(parts[:-2]) + path).lower()

    digits = sum(ch.isdigit() for ch in raw)
    return {
        "url_length": len(raw),
        "host_length": len(host),
        "path_length": len(path),
        "num_dots": raw.count("."),
        "num_hyphens": raw.count("-"),
        "num_at": raw.count("@"),
        "num_question": raw.count("?"),
        "num_equal": raw.count("="),
        "num_underscore": raw.count("_"),
        "num_slash": raw.count("/"),
        "num_digits": digits,
        "digit_ratio": digits / max(len(raw), 1),
        "num_subdomains": max(len(parts) - 2, 0),
        "has_ip": int(_is_ip(host)),
        "has_https": int(parsed.scheme == "https"),
        "has_port": int(parsed.port is not None) if _safe_port(parsed) else 0,
        "is_shortener": int(registered in SHORTENERS),
        "suspicious_tld": int(tld in SUSPICIOUS_TLDS),
        "suspicious_word_count": sum(w in lower for w in SUSPICIOUS_WORDS),
        # brand name appears somewhere other than the real registered domain
        "brand_in_subdomain_or_path": int(
            any(b in sub_and_path for b in BRANDS)
            and not any(registered.startswith(b + ".") for b in BRANDS)
        ),
        "has_double_slash_redirect": int(raw.rfind("//") > 7),
        "entropy": _entropy(host),
        "has_punycode": int("xn--" in host),
        "query_params": len([p for p in parsed.query.split("&") if p]),
    }


def _safe_port(parsed) -> bool:
    try:
        parsed.port
        return True
    except ValueError:
        return False


def url_feature_vector(url: str) -> list:
    f = extract_url_features(url)
    return [f[name] for name in URL_FEATURE_NAMES]


def url_red_flags(url: str) -> list:
    """Human-readable reasons, used to explain a verdict."""
    f = extract_url_features(url)
    flags = []
    if f["has_ip"]:
        flags.append("Uses a raw IP address instead of a domain name")
    if f["num_at"]:
        flags.append("Contains '@', which can hide the real destination")
    if f["is_shortener"]:
        flags.append("Uses a URL shortener that hides the real destination")
    if f["suspicious_tld"]:
        flags.append("Uses a top-level domain often abused for phishing")
    if f["brand_in_subdomain_or_path"]:
        flags.append("Brand name appears outside the real domain (impersonation)")
    if f["suspicious_word_count"] >= 2:
        flags.append("Several credential-related keywords (login, verify, account…)")
    if f["num_subdomains"] >= 3:
        flags.append("Unusually many subdomains")
    if f["num_hyphens"] >= 3:
        flags.append("Many hyphens in the URL")
    if f["url_length"] > 75:
        flags.append("Very long URL")
    if f["has_punycode"]:
        flags.append("Punycode domain (possible look-alike characters)")
    if not f["has_https"]:
        flags.append("Not using HTTPS")
    if f["has_double_slash_redirect"]:
        flags.append("Embedded '//' redirect inside the URL")
    return flags


# ---------------------------------------------------------------- email ----

URGENCY = ["urgent", "immediately", "within 24 hours", "suspended", "act now",
           "final notice", "expire", "locked", "unusual activity", "limited time"]
CREDENTIAL = ["password", "otp", "pin", "cvv", "card number", "login",
              "verify your", "confirm your", "bank details", "aadhaar", "kyc"]
MONEY = ["prize", "lottery", "winner", "refund", "reward", "gift card",
         "claim", "cashback", "inheritance", "bitcoin"]

URL_RE = re.compile(r"(https?://[^\s<>\"']+|www\.[^\s<>\"']+)", re.I)


def extract_urls(text: str) -> list:
    return URL_RE.findall(text or "")


def clean_email_text(text: str) -> str:
    text = (text or "").lower()
    text = URL_RE.sub(" URLTOKEN ", text)
    text = re.sub(r"\S+@\S+", " EMAILTOKEN ", text)
    text = re.sub(r"\d+", " NUMTOKEN ", text)
    text = re.sub(r"[^a-z_ ]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def email_red_flags(text: str) -> list:
    t = (text or "").lower()
    flags = []
    hits = [w for w in URGENCY if w in t]
    if hits:
        flags.append("Urgency / pressure language: " + ", ".join(hits[:3]))
    hits = [w for w in CREDENTIAL if w in t]
    if hits:
        flags.append("Asks for sensitive information: " + ", ".join(hits[:3]))
    hits = [w for w in MONEY if w in t]
    if hits:
        flags.append("Money / prize bait: " + ", ".join(hits[:3]))
    if re.search(r"dear (customer|user|client|sir/madam|account holder)", t):
        flags.append("Generic greeting instead of your name")
    for u in extract_urls(text)[:5]:
        for fl in url_red_flags(u)[:2]:
            flags.append(f"Link {u[:50]}: {fl}")
    return flags
