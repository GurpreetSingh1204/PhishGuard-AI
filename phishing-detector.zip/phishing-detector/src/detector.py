"""
PhishingDetector - the single entry point used by the web app, API and CLI.

Hybrid decision:
    final_score = ML probability                      (no LLM configured)
    final_score = 0.6 * ML + 0.4 * LLM               (LLM configured)
    verdict     = phishing (>= 0.7) / suspicious (>= 0.4) / legitimate
For emails, every link inside the email is also scanned by the URL model and
the highest link score is blended in.
"""
import os
import sys

import joblib

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import llm_analyzer  # noqa: E402
from features import (clean_email_text, email_red_flags, extract_urls,  # noqa: E402
                      url_feature_vector, url_red_flags)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODELS = os.path.join(ROOT, "models")

LLM_SCORE = {"phishing": 1.0, "suspicious": 0.6, "legitimate": 0.0}


def verdict_for(score):
    if score >= 0.7:
        return "phishing"
    if score >= 0.4:
        return "suspicious"
    return "legitimate"


class PhishingDetector:
    def __init__(self, models_dir=MODELS):
        try:
            self.url_model = joblib.load(os.path.join(models_dir, "url_model.joblib"))
            self.email_model = joblib.load(os.path.join(models_dir, "email_model.joblib"))
        except FileNotFoundError:
            raise SystemExit("Models not found. Run: python data/generate_dataset.py && python src/train.py")

    def url_score(self, url):
        return float(self.url_model.predict_proba([url_feature_vector(url)])[0][1])

    def _blend(self, kind, content, ml_score, flags, use_llm):
        llm = llm_analyzer.analyse(kind, content, ml_score, flags) if use_llm else None
        final = ml_score
        if llm and "verdict" in llm:
            llm_s = LLM_SCORE.get(llm["verdict"], 0.5)
            final = 0.6 * ml_score + 0.4 * llm_s
        return {
            "verdict": verdict_for(final),
            "score": round(final, 4),
            "ml_score": round(ml_score, 4),
            "red_flags": flags,
            "llm": llm,
            "llm_enabled": llm_analyzer.llm_available(),
        }

    def scan_url(self, url, use_llm=True):
        score = self.url_score(url)
        result = self._blend("URL", url, score, url_red_flags(url), use_llm)
        result.update(type="url", input=url)
        return result

    def scan_email(self, text, use_llm=True):
        text_score = float(self.email_model.predict_proba([clean_email_text(text)])[0][1])
        links = [{"url": u, "score": round(self.url_score(u), 4)} for u in extract_urls(text)[:10]]
        link_max = max((l["score"] for l in links), default=0.0)
        ml_score = max(text_score, 0.7 * text_score + 0.3 * link_max) if links else text_score
        result = self._blend("email", text, ml_score, email_red_flags(text), use_llm)
        result.update(type="email", text_score=round(text_score, 4), links=links)
        return result


if __name__ == "__main__":
    import argparse
    import json

    p = argparse.ArgumentParser(description="Phishing detector CLI")
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--url")
    g.add_argument("--email", help="email text, or @path/to/file.txt")
    p.add_argument("--no-llm", action="store_true")
    a = p.parse_args()

    d = PhishingDetector()
    if a.url:
        out = d.scan_url(a.url, use_llm=not a.no_llm)
    else:
        text = open(a.email[1:], encoding="utf-8").read() if a.email.startswith("@") else a.email
        out = d.scan_email(text, use_llm=not a.no_llm)
    print(json.dumps(out, indent=2))
