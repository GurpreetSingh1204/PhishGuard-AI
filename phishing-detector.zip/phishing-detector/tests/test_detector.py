"""Run with:  python -m pytest tests -q   (after training the models)"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))
from detector import PhishingDetector  # noqa: E402
from features import URL_FEATURE_NAMES, extract_url_features, url_red_flags  # noqa: E402

d = PhishingDetector()


def test_feature_vector_complete():
    f = extract_url_features("https://www.google.com/search?q=test")
    assert set(URL_FEATURE_NAMES) == set(f)


def test_ip_url_flagged():
    assert any("IP address" in x for x in url_red_flags("http://192.168.10.5/paypal/login"))


def test_phishing_url():
    r = d.scan_url("http://paypal.com.secure-login-verify.xyz/account/update.php", use_llm=False)
    assert r["verdict"] in ("phishing", "suspicious")


def test_legit_url():
    r = d.scan_url("https://github.com/features", use_llm=False)
    assert r["verdict"] == "legitimate"


def test_phishing_email():
    text = ("Dear Customer, your account has been suspended. Verify your password "
            "within 24 hours at http://hdfc-kyc-update.tk/login")
    assert d.scan_email(text, use_llm=False)["verdict"] == "phishing"


def test_legit_email():
    text = "Hi Rahul, attaching the minutes from today's project meeting. See you Monday."
    assert d.scan_email(text, use_llm=False)["verdict"] == "legitimate"
