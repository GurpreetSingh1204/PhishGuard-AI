"""
Generates a synthetic starter dataset so the project runs out of the box.

  data/urls.csv    columns: url,label        (1 = phishing, 0 = legitimate)
  data/emails.csv  columns: text,label

For your final results, replace these with real public datasets, e.g.
  URLs  : PhishTank, OpenPhish, "Phishing Site URLs" (Kaggle), Tranco top-sites list
  Emails: Nazario phishing corpus, Enron (ham), "Phishing Email Detection" (Kaggle)
Keep the same column names and re-run src/train.py.
"""
import csv
import os
import random

random.seed(42)
HERE = os.path.dirname(os.path.abspath(__file__))

LEGIT_DOMAINS = [
    "google.com", "youtube.com", "wikipedia.org", "amazon.in", "github.com",
    "stackoverflow.com", "microsoft.com", "apple.com", "linkedin.com",
    "sbi.co.in", "hdfcbank.com", "icicibank.com", "irctc.co.in", "gov.in",
    "nptel.ac.in", "flipkart.com", "zomato.com", "netflix.com", "paypal.com",
    "python.org", "bbc.com", "thehindu.com", "medium.com", "reddit.com",
    "ibm.com", "oracle.com", "coursera.org", "udemy.com", "kaggle.com",
]
LEGIT_PATHS = [
    "", "/", "/about", "/search?q=python+tutorial", "/docs/getting-started",
    "/wiki/Machine_learning", "/products/laptops", "/en-in/help", "/news/world",
    "/courses/cyber-security", "/blog/2026/11/release-notes", "/careers",
    "/watch?v=dQw4w9WgXcQ", "/user/settings", "/questions/12345/how-to",
]
BRANDS = ["paypal", "apple", "microsoft", "amazon", "netflix", "sbi", "hdfc",
          "icici", "paytm", "google", "facebook", "instagram", "whatsapp"]
BAD_TLDS = ["tk", "ml", "ga", "cf", "xyz", "top", "click", "icu", "buzz", "info"]
BAD_WORDS = ["login", "verify", "secure", "account", "update", "confirm",
             "signin", "billing", "kyc", "unlock", "reward", "support"]
SHORT = ["bit.ly", "tinyurl.com", "cutt.ly", "rb.gy", "is.gd"]


def rand_str(n, chars="abcdefghijklmnopqrstuvwxyz0123456789"):
    return "".join(random.choice(chars) for _ in range(n))


def legit_url():
    d = random.choice(LEGIT_DOMAINS)
    sub = random.choice(["", "www.", "www.", "docs.", "m.", "mail."])
    return f"https://{sub}{d}{random.choice(LEGIT_PATHS)}"


def phish_url():
    b, w, tld = random.choice(BRANDS), random.choice(BAD_WORDS), random.choice(BAD_TLDS)
    style = random.randint(0, 8)
    scheme = random.choice(["http", "http", "https"])
    if style == 0:
        return f"{scheme}://{b}-{w}-{rand_str(4)}.{tld}/{w}.php"
    if style == 1:
        ip = ".".join(str(random.randint(1, 254)) for _ in range(4))
        return f"http://{ip}/{b}/{w}/index.html"
    if style == 2:
        return f"{scheme}://{b}.com.{w}-{rand_str(5)}.{tld}/?session={rand_str(16)}"
    if style == 3:
        return f"https://{random.choice(SHORT)}/{rand_str(6, 'abcdefghijkABCDEFG0123456789')}"
    if style == 4:
        return f"http://www.{b}.com@{rand_str(8)}.{tld}/{w}"
    if style == 5:
        return f"{scheme}://secure.{w}.{b}.{rand_str(6)}.{tld}/{w}/{rand_str(10)}?id={random.randint(1000,99999)}"
    if style == 6:
        return f"http://{rand_str(12)}.{tld}/{b}/{w}-{w}/redirect//{b}.com"
    if style == 7:
        return f"https://xn--{b}{rand_str(3)}.{tld}/{w}"
    return f"{scheme}://{b}{random.randint(1,999)}-{w}.{random.choice(['com','net','org',tld])}/{w}/{rand_str(8)}.html"


HAM_TEMPLATES = [
    "Hi {name}, attaching the minutes from today's project meeting. Let me know if I missed anything.",
    "Your order #{num} has been shipped and will arrive by {day}. Track it from your orders page.",
    "Reminder: the department seminar on {topic} is on {day} at 3 PM in Lab 2.",
    "Hey {name}, are we still on for lunch on {day}? I can book a table.",
    "The assignment on {topic} is due {day}. Submit the PDF on the course portal.",
    "Thanks for your payment. Your electricity bill for this month is settled. No action needed.",
    "Hi team, the build passed. I merged the {topic} branch into main.",
    "Please find the revised report on {topic} attached. Comments welcome before {day}.",
    "Your monthly statement is now available in net banking. We will never ask for your PIN or OTP.",
    "Welcome to the {topic} course! The first lecture video is available on the course page.",
    "{name}, happy birthday! Hope you have a great day.",
    "The library has renewed your book on {topic}. New due date: {day}.",
]
PHISH_TEMPLATES = [
    "Dear Customer, your {brand} account has been suspended due to unusual activity. Verify your account immediately at {url} or it will be permanently locked.",
    "URGENT: Your KYC is pending. Update your Aadhaar and PAN within 24 hours to avoid account block: {url}",
    "Congratulations! You are the lucky winner of a {brand} lottery prize of Rs {num},000. Claim your reward now: {url}",
    "Dear user, we detected a login from a new device. If this wasn't you, confirm your password here {url}",
    "Your {brand} payment failed. Update your billing information and card number within 24 hours: {url}",
    "Final notice: your mailbox storage is full. Click {url} and login to avoid losing emails.",
    "Refund of Rs {num} is pending from Income Tax Dept. Submit your bank details to claim: {url}",
    "Dear account holder, share the OTP sent to your phone to complete verification. Act now.",
    "Your {brand} subscription will expire today. Renew immediately with your card details: {url}",
    "You have received a gift card worth Rs {num}. Limited time! Claim at {url}",
    "Security alert: unusual activity on your {brand} account. Confirm your identity within 24 hours {url}",
    "Your parcel is on hold due to unpaid customs fee. Pay now to release delivery: {url}",
]
NAMES = ["Rahul", "Priya", "Aman", "Simran", "Karan", "Neha", "Arjun", "Ananya"]
TOPICS = ["cyber forensics", "machine learning", "cloud security", "databases",
          "network security", "blockchain", "malware analysis"]
DAYS = ["Monday", "Tuesday", "Friday", "next week", "the 25th", "tomorrow"]


def ham_email():
    return random.choice(HAM_TEMPLATES).format(
        name=random.choice(NAMES), num=random.randint(10000, 99999),
        day=random.choice(DAYS), topic=random.choice(TOPICS))


def phish_email():
    return random.choice(PHISH_TEMPLATES).format(
        brand=random.choice(BRANDS).upper() if random.random() < .3 else random.choice(BRANDS).title(),
        url=phish_url(), num=random.randint(5, 99))


def write(path, header, rows):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


if __name__ == "__main__":
    n = 3000
    urls = [(legit_url(), 0) for _ in range(n)] + [(phish_url(), 1) for _ in range(n)]
    random.shuffle(urls)
    write(os.path.join(HERE, "urls.csv"), ["url", "label"], urls)

    emails = [(ham_email(), 0) for _ in range(n // 2)] + [(phish_email(), 1) for _ in range(n // 2)]
    random.shuffle(emails)
    write(os.path.join(HERE, "emails.csv"), ["text", "label"], emails)
    print(f"Wrote {len(urls)} URLs and {len(emails)} emails to {HERE}")
